/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/chartiq.js";


let __js_standard_markers_ = (_exports) => {

/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

// Make sure this file is only executed once
if (!CIQ.Marker) {
	CIQ.ChartEngine.helpersToRegister.push(function (stx) {
		stx.markerHelper = {
			chartMap: {},
			classMap: {},
			domMarkers: [],
			highlighted: []
		};
	});

	/**
	 * Adds a marker to the chart.
	 *
	 * @param {CIQ.Marker} marker The marker to add.
	 *
	 * @memberOf CIQ.ChartEngine
	 * @private
	 * @since 7.2.0 Checks for the `prepareForHolder` method on the markers's `stxNodeCreator` and
	 * 		calls that function if present.
	 */
	CIQ.ChartEngine.prototype.addToHolder = function (marker) {
		var panel = this.panels[marker.params.panelName];
		if (!panel) return;

		// if (!this.markerHelper) this.makeMarkerHelper();

		var mparams = marker.params,
			node = marker.node,
			nodeCreator = marker.stxNodeCreator;
		if (nodeCreator && nodeCreator.prepareForHolder) {
			node = nodeCreator.prepareForHolder(marker);
		}
		if (mparams.chartContainer) {
			this.container.appendChild(marker.node);
		} else if (mparams.includeAxis) {
			panel.holder.appendChild(marker.node);
		} else {
			panel.subholder.appendChild(node);
		}

		marker.chart = panel.chart;
		if (nodeCreator && nodeCreator.addToHolder) nodeCreator.addToHolder(marker);
		if (nodeCreator && nodeCreator.expand) {
			CIQ.Marker.initializeScrollBehavior(nodeCreator);
		}
	};

	/**
	 * Gets an array of markers
	 * @private
	 * @param {string} type The type of comparison "panelName","label","all"
	 * @param {string} comparison The value to compare to
	 * @return {array} The marker array
	 */
	CIQ.ChartEngine.prototype.getMarkerArray = function (type, comparison) {
		var arr = [];
		for (var label in this.markers) {
			for (var i = 0; i < this.markers[label].length; i++) {
				var marker = this.markers[label][i];
				if (type == "panelName") {
					if (marker.params.panelName == comparison) arr.push(marker);
				} else if (type == "label") {
					if (label == comparison) arr.push(marker);
				} else if (type == "all") {
					arr.push(marker);
				}
			}
		}
		return arr;
	};

	/**
	 * Removes the marker from the chart
	 * @private
	 * @param  {CIQ.Marker} marker The marker to remove
	 * @memberOf CIQ.ChartEngine
	 */
	CIQ.ChartEngine.prototype.removeFromHolder = function (marker) {
		var panel = this.panels[marker.params.panelName];
		if (panel) {
			if (marker.node.parentNode == panel.holder)
				panel.holder.removeChild(marker.node);
			else if (marker.node.parentNode == panel.subholder)
				panel.subholder.removeChild(marker.node);
			else if (marker.node.parentNode == this.container)
				this.container.removeChild(marker.node);
		}
		// Remove from label map
		var labels = this.markers[marker.params.label];
		if (!labels) return;
		var i;
		for (i = 0; i < labels.length; i++) {
			if (labels[i] === marker) {
				labels.splice(i, 1);
				break;
			}
		}

		// remove from chart map
		var chartMap = this.markerHelper.chartMap[marker.chart.name];
		if (chartMap) {
			for (i = 0; i < chartMap.markers.length; i++) {
				if (chartMap.markers[i] === marker) {
					chartMap.markers.splice(i, 1);
					break;
				}
			}
		}

		// remove from class map
		var classMap = this.markerHelper.classMap[marker.className];
		if (classMap) {
			var panelArray = classMap[marker.params.panelName];
			if (panelArray) {
				for (i = 0; i < panelArray.length; i++) {
					if (panelArray[i] === marker) {
						panelArray.splice(i, 1);
						break;
					}
				}
			}
		}
	};

	/**
	 * Moves the markers from one panel to another
	 * Useful when renaming panels
	 * @param  {string} fromPanelName The panel to move markers from
	 * @param  {string} toPanelName The panel to move markers to
	 * @memberOf CIQ.ChartEngine
	 * @since 2016-07-16
	 */
	CIQ.ChartEngine.prototype.moveMarkers = function (
		fromPanelName,
		toPanelName
	) {
		var arr = this.getMarkerArray("panelName", fromPanelName);
		for (var i = 0; i < arr.length; i++) {
			arr[i].params.panelName = toPanelName;
		}
		for (var className in this.markerHelper.classMap) {
			var tmp = this.markerHelper.classMap[className][fromPanelName];
			if (tmp) {
				this.markerHelper.classMap[className][toPanelName] = tmp;
				delete this.markerHelper.classMap[className][fromPanelName];
			}
		}
	};

	/**
	 * Establishes the tick value for any markers that have a "date" specified. It tries to be efficient, not recalculating
	 * unless the size of the dataSet for a chart has actually changed
	 * @private
	 * @memberOf CIQ.ChartEngine
	 */
	CIQ.ChartEngine.prototype.establishMarkerTicks = function () {
		// if (!this.markerHelper) this.makeMarkerHelper();
		var chartMap = this.markerHelper.chartMap;
		for (var chart in chartMap) {
			var chartEntry = chartMap[chart];
			if (chartEntry.dataSetLength == this.charts[chart].dataSet.length)
				continue;
			for (var i = 0; i < chartEntry.markers.length; i++) {
				this.setMarkerTick(chartEntry.markers[i]);
			}
		}
	};

	/**
	 * Figures out the position of a future marker but only if it is displayed on the screen.
	 * @param  {CIQ.Marker} marker The marker to check
	 * @memberOf CIQ.ChartEngine
	 */
	CIQ.ChartEngine.prototype.futureTickIfDisplayed = function (marker) {
		var chart = marker.chart;
		if (chart.dataSet.length < 1) return;
		var xaxisDT = chart.xaxis[chart.xaxis.length - 1].DT;

		xaxisDT = new Date(xaxisDT.getTime() - this.timeZoneOffset * 60000);
		if (marker.params.x > xaxisDT) return; // not displayed on screen yet

		// It should be displayed on the screen now so find the exact tick
		var futureTicksOnScreen = chart.maxTicks - chart.dataSegment.length;
		var ticksToSearch = chart.dataSet.length + futureTicksOnScreen;
		var pms, qms;
		var dt = new Date(+chart.dataSet[chart.dataSet.length - 1].DT);

		var iter = this.standardMarketIterator(dt, null, chart);

		var dms = marker.params.x.getTime();
		for (var j = chart.dataSet.length; j < ticksToSearch; j++) {
			pms = dt.getTime();
			dt = iter.next();
			qms = dt.getTime();
			// If the event lands on that day, or if the event landed between bars
			if (qms == dms) {
				marker.tick = j;
				return;
			} else if (qms > dms && pms < dms) {
				marker.tick = Math.max(j - 1, 0);
				return;
			}
		}
	};

	/**
	 * Establishes the tick value for the specified marker. We do this to avoid calculating the date every time we want
	 * to place the marker. Converting date to tick is a very expensive operation!
	 * @param {CIQ.Marker} marker The marker for which to establish the tick
	 * @private
	 * @memberOf CIQ.ChartEngine
	 */
	CIQ.ChartEngine.prototype.setMarkerTick = function (marker) {
		var chart = marker.chart;
		if (marker.params.xPositioner == "master" && marker.params.x) {
			marker.tick = Math.floor(marker.params.x / this.layout.periodicity);
			return;
		} else if (marker.params.xPositioner == "date" && marker.params.x) {
			var pms, qms;
			var dms = marker.params.x.getTime();
			for (var i = 0; i < chart.dataSet.length; i++) {
				var quotes = chart.dataSet[i];
				qms = quotes.DT.getTime();
				pms = qms;
				if (i > 0) pms = chart.dataSet[i - 1].DT.getTime();
				// If the event lands on that day, or if the event landed between bars
				if (qms == dms) {
					marker.tick = i;
					return;
				} else if (qms > dms && pms < dms) {
					marker.tick = Math.max(i - 1, 0);
					return;
				} else if (dms < qms) {
					marker.tick = null;
					// marker date is in distant past, shortcircuit the logic for performance.
					return;
				}
			}
			if (chart.dataSet.length < 1) return;
			var dt = new Date(+chart.dataSet[i - 1].DT);
			if (dt.getTime() < dms) marker.params.future = true;
			marker.tick = null; // reset in case we had figured it out with an earlier dataset
		}
	};

	/**
	 * <span class="injection">INJECTABLE</span>
	 * <span class="animation">Animation Loop</span>
	 *
	 * Iterates through all marker handlers, calling their corresponding custom `placementFunction` or {@link CIQ.ChartEngine#defaultMarkerPlacement} if none defined.
	 * @memberOf CIQ.ChartEngine.AdvancedInjectable#
	 * @alias positionMarkers
	 */
	CIQ.ChartEngine.prototype.positionMarkers = function () {
		var self = this,
			chart = this.chart;
		if (!self.markerHelper) return;

		function draw() {
			if (self.runPrepend("positionMarkers", arguments)) return;
			self.markerTimeout = null;
			for (var className in self.markerHelper.classMap) {
				for (var panelName in self.markerHelper.classMap[className]) {
					var arr = self.markerHelper.classMap[className][panelName];
					var panel = self.panels[panelName];
					if (arr.length) {
						var params = {
							stx: self,
							arr: arr,
							panel: panel
						};
						params.firstTick = panel.chart.dataSet.length - panel.chart.scroll;
						params.lastTick = params.firstTick + panel.chart.dataSegment.length;

						var fn = arr[0].constructor.placementFunction; // Some magic, this gets the static member "placementFunction" of the class (not the instance)
						if (fn) {
							fn(params);
						} else {
							self.defaultMarkerPlacement(params);
						}
					}
				}
			}
			self.runAppend("positionMarkers", arguments);
		}

		if (this.markerDelay || this.markerDelay === 0) {
			if (!this.markerTimeout)
				this.markerTimeout = setTimeout(draw, this.markerDelay);
		} else {
			draw();
		}
		var starting = this.getFirstLastDataRecord(chart.dataSegment, "tick"),
			ending = this.getFirstLastDataRecord(chart.dataSegment, "tick", true);
		if (!starting || !ending) return; // return if dataSegment is full of nulls or undefined values or maybe its just empty

		var markers = this.getMarkerArray("all");
		for (var i = 0; i < markers.length; i++) {
			var marker = markers[i],
				nodeCreator = marker.stxNodeCreator;
			if (starting.tick <= marker.tick && marker.tick <= ending.tick) {
				// if markers are off screen don't draw them
				if (nodeCreator && nodeCreator.drawMarker)
					nodeCreator.drawMarker(marker);
			} else if (marker.attached && nodeCreator.expand) {
				// hide the popup of any perf markers outside the dataSegment
				nodeCreator.expand.style.visibility = "hidden";
			}
		}
	};

	/**
	 * A marker is a DOM object that is managed by the chart.
	 *
	 * Makers are placed in containers which are `div` elements whose placement and size correspond with a panel on the
	 * chart. A container exists for each panel.
	 *
	 * A marker's primary purpose is to provide additional information for a data point on the chart. As such, markers
	 * can be placed by date, tick, or bar to control their position on the x-axis, and by value (price) to control their
	 * position on the y-axis. Additional default positioning is also available, including the ability to create custom
	 * positioning logic. Once the positioning logic is established for markers, they are repositioned as needed when the
	 * user scrolls or zooms the chart.
	 *
	 * Alternatively, a marker can also be placed at an absolute position using CSS positioning, in which case the chart
	 * does not control the marker's positioning.
	 *
	 * The default placement function for any markers is {@link CIQ.ChartEngine#defaultMarkerPlacement}.
	 *
	 * See the {@tutorial Markers} tutorial for additional implementation details and information about managing
	 * performance on deployments requiring a large number of markers.
	 *
	 * @name CIQ.Marker
	 * @param {Object} params Parameters that describe the marker.
	 * @param {CIQ.ChartEngine} params.stx The chart to which the marker is attached.
	 * @param {*} params.x A valid date, tick, or bar (depending on the selected `xPositioner`) used to select a candle to
	 * 					which the marker is associated.
	 * @param {Number} params.y A valid value for positioning the marker on the y-axis (depending on selected `yPositioner`).
	 * 					If this value is not provided, the marker is set "above_candle" as long as a valid candle is selected
	 * 					by `params.x`.
	 * @param {HTMLElement} [params.node] The HTML element that contains the marker. This element should be detached from the
	 * 					DOM. If an element is not provided, an empty `div` is created. You can create your own or use the provided {@link CIQ.Marker.Simple} and {@link CIQ.Marker.Performance} node creators.
	 * @param {string} params.panelName="chart" The name of the panel to which the `node` is attached. Defaults to the main
	 * 					chart panel.
	 * @param {string} [params.xPositioner="date"] Determines the x-axis position of the marker.
	 * Values include:
	 * - "date" &mdash; `params.x` must be set to a JavaScript date object. This will be converted to the closest `masterData`
	 * position if the provided date does not exactly match any existing points. Be sure the same timezone as masterData is used.
	 * - "master" &mdash; `params.x` must be set to a `masterData` position.
	 * - "bar" &mdash; `params.x` must be set to a `dataSegment` position.
	 * - "none" &mdash; Use CSS positioning; `params.x` is not used.
	 * @param {string} [params.yPositioner="value"] Determines the y-axis position of the marker.
	 * Values include:
	 * - "value" &mdash; `params.y` must be set to an exact y-axis value. If `params.y` is omitted, the y-axis position defaults
	 * to "above_candle".
	 * - "above_candle" &mdash; Positions the marker right above the candle or line. If more than one marker is at the same position,
	 * the markers are aligned upwards from the first. The `params.y` value is not used.
	 * - "below_candle" &mdash; Positions the marker right below the candle or line. If more than one marker is at the same position,
	 * the markers are aligned downwards from the first. The `params.y` value is not used.
	 * - "under_candle" &mdash; Deprecated; same as "below_candle".
	 * - "on_candle" &mdash; Position the marker in the center of the candle or line, covering it. If more than one marker is at the
	 * same position, the markers are aligned downwards from the first. The `params.y` value is not used.
	 * - "top" &mdash; Position the marker at the top of the chart, right below the margin. If more than one marker is at the same
	 * position, the markers are aligned downwards from the first. The `params.y` value is not used.
	 * - "bottom" &mdash; Position the marker at the bottom of the chart, right above the margin. If more than one marker is at the
	 * same position, the markers are aligned upwards from the first. The `params.y` value is not used.
	 * - "none" &mdash; Use CSS positioning; `params.y` is not used.
	 * @param {boolean} [params.permanent=false] The marker stays on the chart even when the chart is re-initialized by a symbol
	 * change, call to `loadChart()` or `initializeChart()`, and so forth.
	 * @param {string} [params.label="generic"] A label for the marker. Multiple markers can be assigned the same label, which
	 * allows them to be deleted simultaneously.
	 * @param {boolean} [params.includeAxis=false] If true, then the marker can display on the x- or y-axis. Otherwise, it is cropped
	 * at the axis edge.
	 * @param {Boolean} [params.chartContainer] If true, then the marker is placed directly in the chart container as opposed to in a
	 * container, or holder, node. When placing the marker directly in the chart container, the z-index setting for the marker should
	 * be set in relation to the z-index of other holders in order to place the marker above or below markers inside the holders.
	 * @constructor
	 * @since
	 * - 15-07-01
	 * - 05-2016-10 Added the following `params.yPositioner` values: "value", "above_candle",
	 * 		"below_candle", "on_candle", "top", and "bottom".
	 * @version ChartIQ Advanced Package
	 * @example
	 * new CIQ.Marker({
	 *     stx: stxx,
	 * 	   xPositioner: "date",
	 *     yPositioner: "value",
	 * 	   x: someDate,
	 * 	   y: somePrice,
	 * 	   label: "events",
	 * 	   node: newNode
	 * });
	 */
	CIQ.Marker =
		CIQ.Marker ||
		function (params) {
			this.params = {
				xPositioner: "date",
				yPositioner: "value",
				panelName: "chart",
				permanent: false,
				label: "generic",
				includeAxis: false
			};
			CIQ.extend(this.params, params);
			if (!this.params.node) {
				this.params.node = document.createElement("DIV");
			}
			var stx = this.params.stx;
			if (!stx) {
				console.log("Marker created without specifying stx");
				return;
			}
			if (!this.className) this.className = "CIQ.Marker";

			// Switcheroo. If a NodeCreator is passed in, then we change the marker
			// to reference the actual DOM node and then we add stxNodeCreator to the
			// marker so that we can reference it if need be
			if (CIQ.derivedFrom(this.params.node, CIQ.Marker.NodeCreator)) {
				this.stxNodeCreator = this.params.node;
				this.node = this.stxNodeCreator.node;
			} else {
				this.node = this.params.node;
			}

			// if (!stx.markerHelper) stx.makeMarkerHelper();

			var label = this.params.label;
			if (!stx.markers[label]) stx.markers[label] = [];
			stx.markers[label].push(this);

			var panel = stx.panels[this.params.panelName];
			this.chart = panel.chart;

			// Put it in the map of charts
			if (!stx.markerHelper.chartMap[this.chart.name]) {
				stx.markerHelper.chartMap[this.chart.name] = {
					dataSetLength: 0,
					markers: []
				};
			}
			stx.markerHelper.chartMap[this.chart.name].markers.push(this);

			var classMap = stx.markerHelper.classMap[this.className];
			if (!classMap) classMap = stx.markerHelper.classMap[this.className] = {};
			if (!classMap[this.params.panelName])
				classMap[this.params.panelName] = [];
			classMap[this.params.panelName].push(this);

			var defer = this.stxNodeCreator && this.stxNodeCreator.deferAttach;
			if (!defer) stx.addToHolder(this);
			stx.setMarkerTick(this);

			if (this.stxNodeCreator && this.stxNodeCreator.drawMarker)
				this.stxNodeCreator.drawMarker(this);
		};

	/**
	 * Removes the marker from the chart object
	 * @memberOf CIQ.Marker
	 * @since 15-07-01
	 */
	CIQ.Marker.prototype.remove = function () {
		this.params.stx.removeFromHolder(this);
	};

	/**
	 * Called when a marker node is clicked. Checks to see whether the node has its own click
	 * function and, if it does, calls that function, passing all arguments to it.
	 *
	 * @param {object} params Configuration parameters.
	 * @param {number} params.cx The clientX coordinate of the click event.
	 * @param {number} params.cy The clientY coordinate of the click event.
	 * @param {CIQ.ChartEngine.Panel} params.panel Panel where the click took place.
	 *
	 * @memberof CIQ.Marker
	 * @since
	 * - 7.2.0
	 * - 8.0.0 Signature changed to accept the `params` object.
	 */
	CIQ.Marker.prototype.click = function (params) {
		if (typeof arguments[0] === "number") {
			params = { cx: arguments[0], cy: arguments[1], panel: arguments[3] };
		}

		let { cx, cy, panel } = params;
		if (!this.params.stx) return; // some markers don't know the engine. In that scenario do nothing.
		var node = this.params.node;
		if (node.click) node.click(cx, cy, this, panel);
	};

	/**
	 * Called when a marker node is double-clicked.
	 *
	 * Override this function with your own implementation. Return a truthy value to prevent
	 * {@link CIQ.ChartEngine#doubleClick} from dispatching the "doubleClick" event and invoking
	 * the [doubleClickEventListener]{@link CIQ.ChartEngine~doubleClickEventListener}.
	 *
	 * @param {object} params Configuration parameters.
	 * @param {number} params.cx The clientX coordinate of the double-click event.
	 * @param {number} params.cy The clientY coordinate of the double-click event.
	 * @param {CIQ.ChartEngine.Panel} params.panel Panel where the double-click took place.
	 * @return {boolean} true to indicate the double-click event has been handled; otherwise,
	 * 		false.
	 *
	 * @alias doubleClick
	 * @memberof CIQ.Marker.prototype
	 * @virtual
	 * @since 8.0.0
	 */
	CIQ.Marker.prototype.doubleClick = function ({ cx, cy, panel }) {
		return false;
	};

	/**
	 * Normally the chart will take care of positioning the marker automatically but you can
	 * force a marker to render itself by calling this method. This will cause the marker to
	 * call its placement function. You might want to do this for instance if your marker morphs
	 * or changes position outside of the animation loop.
	 */
	CIQ.Marker.prototype.render = function () {
		var arr = [this];
		var params = {
			stx: this.params.stx,
			arr: arr,
			panel: this.params.stx.panels[this.params.panelName],
			showClass: this.showClass
		};
		this.constructor.placementFunction(params);
	};

	/**
	 * Removes all markers with the specified label from the chart object
	 * @param  {CIQ.ChartEngine} stx   The chart object
	 * @param  {string} label The label
	 * @memberOf CIQ.Marker
	 * @since 15-07-01
	 */
	CIQ.Marker.removeByLabel = function (stx, label) {
		var arr = stx.getMarkerArray("label", label);
		for (var i = 0; i < arr.length; i++) {
			var marker = arr[i];
			stx.removeFromHolder(marker);
			if (marker.stxNodeCreator && marker.stxNodeCreator.remove) {
				marker.stxNodeCreator.remove(marker);
			}
		}
		stx.draw();
	};

	/**
	 *
	 * Content positioner for any markers using the 'stx-marker-expand' class,
	 * this will consider the marker node's location within its container and determine where to
	 * place the content, be it to the left or right/top or bottom of the marker node (so it is all showing)
	 * @memberOf CIQ.Marker
	 * @param {HTMLElement} node The HTML element representing the marker which has content
	 * @since 5.1.2
	 */
	CIQ.Marker.positionContentVerticalAndHorizontal = function (node) {
		var content_node = node.querySelectorAll(".stx-marker-expand")[0];
		if (!content_node || !CIQ.trulyVisible(content_node)) return;

		var offsetHeight = content_node.offsetHeight;
		var nodeStyle = content_node.style;
		nodeStyle.left = nodeStyle.right = ""; // reset content to right of node
		nodeStyle.bottom = nodeStyle.top = ""; // reset content to bottom of node

		var computedNodeStyle = getComputedStyle(content_node);
		var contentLeft = computedNodeStyle.left;
		var contentBottom = computedNodeStyle.bottom;

		var leftPxOfContent = node.offsetLeft + parseInt(contentLeft, 10);
		var bottomContentInt = parseInt(contentBottom, 10);

		// Subtract the difference between the content top and the parent height from the offsetTop
		var topPxOfContent =
			node.offsetTop - (bottomContentInt + offsetHeight - node.offsetHeight);

		var offsetMaxWidth = node.parentNode.offsetWidth;
		var offsetMaxHeight = node.parentNode.offsetHeight;

		//switch content to left of node if node is off the left of the chart or content will not fit to the right of the node
		if (leftPxOfContent + content_node.offsetWidth > offsetMaxWidth) {
			nodeStyle.right = contentLeft;
			nodeStyle.left = "auto";
		}

		if (node.offsetTop <= offsetMaxHeight) {
			//node not off the bottom of the chart
			//switch content to top of node if node is off the bottom of the chart or content will not fit to the bottom of the node
			if (topPxOfContent > offsetMaxHeight - offsetHeight) {
				nodeStyle.top = offsetMaxHeight - node.offsetTop - offsetHeight + "px";
				nodeStyle.bottom = "auto";
			}
		} else {
			nodeStyle.top = offsetMaxHeight + "px";
		}
		if (node.offsetTop + node.offsetHeight >= 0) {
			//node not off the top of the chart
			//switch content to bottom of node if node is off the top of the chart or content will not fit to the top of the node
			if (topPxOfContent < 0) {
				nodeStyle.top = -node.offsetTop + "px";
				nodeStyle.bottom = "auto";
			}
		} else {
			nodeStyle.bottom = "0px";
		}
	};

	/**
	 * Initializes the scroll behavior of marker expands.
	 *
	 * For proper styling, the perfect scrollbar requires elements to have been mounted on the DOM
	 * prior to initialization. As a result, this function should only be called on mounted nodes.
	 *
	 * @param {HTMLElement} node The marker that contains the expand for which scroll behavior is
	 * 		initialized.
	 *
	 * @memberof CIQ.Marker
	 * @since 8.2.0
	 */
	CIQ.Marker.initializeScrollBehavior = function (node) {
		const { expand } = node;
		if (!expand) return;

		expand.addEventListener(CIQ.wheelEvent, (e) => e.stopPropagation(), {
			passive: false
		});
		expand.addEventListener("touchmove", (e) => e.stopPropagation(), {
			passive: false
		});
		const { scrollbarStyling } = CIQ.UI || {};
		if (scrollbarStyling) {
			scrollbarStyling.refresh(expand);
		} else {
			expand.style.overflowY = "scroll";
		}
	};

	/**
	 * The above_candle and below_candle y-positioner will usually use the high and low to place the marker.
	 * However, some chart renderings will draw the extent of the bar either inside or outside the high/low range.
	 * For those chart types, this function will return the actual high/low to be used by the marker placement function.
	 * This is only valid when {@link CIQ.Renderer#highLowBars} is true.
	 * Currently this function will handle p&f and histogram chart types.
	 * For any other chart type, define "markerHigh" and "markerLow" for each bar in the dataSet/dataSegment
	 * and these will be honored and returned.
	 * Note: This function may be used with any markerPlacement function to give the lowest and highest point of the bar.
	 *
	 * @memberOf CIQ.ChartEngine
	 * @param {Object} quote The bar's data.  This can come from the chart.dataSet
	 * @return {Object}        The high and low for the marker
	 * @since
	 * - 3.0.0
	 * - 6.2.0 Will consider `Open` and `Close` if `High` and/or `Low` are missing from quote.
	 */
	CIQ.ChartEngine.prototype.getBarBounds = function (quote) {
		var type = this.layout.chartType,
			aggregation = this.layout.aggregationType;
		var bounds;
		if (aggregation == "pandf")
			bounds = {
				high: Math.max(quote.pfOpen, quote.pfClose),
				low: Math.min(quote.pfOpen, quote.pfClose)
			};
		else bounds = { high: quote.High, low: quote.Low };
		if (quote.markerHigh) bounds.high = quote.markerHigh;
		if (quote.markerLow) bounds.low = quote.markerLow;

		var O, H, L;
		if (quote.Open === undefined) O = quote.Close;
		if (quote.High === undefined) H = Math.max(quote.Open || O, quote.Close);
		if (quote.Low === undefined) L = Math.min(quote.Open || O, quote.Close);
		if (!bounds.high && bounds.high !== 0) bounds.high = H;
		if (!bounds.low && bounds.low !== 0) bounds.low = L;
		return bounds;
	};

	/**
	 * Placement functions are responsible for positioning markers in their holder according to each marker's settings.
	 * They are called directly form the draw() function in the animation loop.
	 * Each Marker placement handler must have a corresponding `placementFunction` or this method will be used.
	 *
	 * `firstTick` and `lastTick` can be used as a hint as to whether to display a marker or not.
	 *
	 * See {@link CIQ.Marker} and {@tutorial Markers} for more details
	 * @memberOf CIQ.ChartEngine
	 * @param {object} params The parameters
	 * @param {array} params.arr The array of markers
	 * @param {object} params.panel The panel to display
	 * @param {number} params.firstTick The first tick displayed on the screen
	 * @param {number} params.lastTick The last tick displayed on the screen
	 * @since 2015-09-01 On prior versions you must define your own default function. Example: `CIQ.ChartEngine.prototype.defaultMarkerPlacement = yourPlacementFunction;`.
	 */
	CIQ.ChartEngine.prototype.defaultMarkerPlacement = function (params) {
		var panel = params.panel;
		var yAxis = params.yAxis ? params.yAxis : params.panel.yAxis;
		var chart = panel.chart;
		var stx = params.stx;

		var showsHighs = stx.chart.highLowBars;
		var plotField = chart.defaultPlotField;
		if (!plotField || showsHighs) plotField = "Close";

		var placementMap = {};

		for (var i = 0; i < params.arr.length; i++) {
			var marker = params.arr[i],
				mparams = marker.params;
			if (marker.params.box) continue; // do not try to position drawn markers
			var node = marker.node;
			// Getting clientWidth and clientHeight is a very expensive operation
			// so we'll cache the results. Don't use this function if your markers change
			// shape or size dynamically!
			if (!marker.clientWidth) marker.clientWidth = node.clientWidth;
			if (!marker.clientHeight) marker.clientHeight = node.clientHeight;
			var quote = null;

			// X axis positioning logic

			var xPositioner = mparams.xPositioner,
				yPositioner = mparams.yPositioner,
				tick = marker.tick,
				dataSet = chart.dataSet,
				clientWidth = marker.clientWidth;
			if (xPositioner != "none") {
				if (xPositioner == "bar" && mparams.x) {
					if (mparams.x < chart.xaxis.length) {
						var xaxis = chart.xaxis[mparams.x];
						if (xaxis) quote = xaxis.data;
					}
					node.style.left =
						Math.round(stx.pixelFromBar(mparams.x, chart) - clientWidth / 2) +
						1 +
						"px";
				} else {
					// This is a section of code to hide markers if they are off screen, and also to figure out
					// the position of markers "just in time"
					// the tick is conditionally pre-set by CIQ.ChartEngine.prototype.setMarkerTick depending on marker.params.xPositioner
					if (!tick && tick !== 0) {
						// if tick is not defined then hide, probably in distant past
						if (mparams.future && chart.scroll < chart.maxTicks) {
							// In future
							stx.futureTickIfDisplayed(marker); // Just in time check for tick
							tick = marker.tick; //copy new tick from prior function
							if (!tick && tick !== 0) {
								node.style.left = "-1000px";
								continue;
							}
						} else {
							node.style.left = "-1000px";
							continue;
						}
					}
					if (tick < dataSet.length) quote = dataSet[tick];
					marker.leftpx = Math.round(
						stx.pixelFromTick(tick, chart) - chart.left - clientWidth / 2
					);
					marker.rightEdge = marker.leftpx + clientWidth;
					node.style.left = marker.leftpx + "px";
					if (tick < params.firstTick && marker.rightEdge < chart.left - 50)
						continue; // off screen, no need to reposition the marker (accounting 50px for any visual effects)
				}
				if (!quote) quote = dataSet[dataSet.length - 1]; // Future ticks based off the value of the current quote
			} else if (yPositioner.indexOf("candle") > -1) {
				// candle positioning, find the quote
				var left = getComputedStyle(node).left;
				if (left) {
					var bar = stx.barFromPixel(parseInt(left, 10), chart);
					if (bar >= 0) {
						quote = chart.xaxis[bar].data;
						if (!quote) quote = dataSet[dataSet.length - 1]; // Future ticks based off the value of the current quote
					}
				}
			}

			node.style.top = "auto"; // don't use top positioning with DOM markers
			// Y axis positioning logic
			var y = mparams.y,
				clientHeight = marker.clientHeight,
				val;
			if (yPositioner != "none") {
				var placementKey = yPositioner + "-" + node.style.left;
				var height = mparams.chartContainer ? stx.height : panel.yAxis.bottom;
				var bottom = 0,
					bottomAdjust = 0;
				if (typeof placementMap[placementKey] == "undefined") {
					placementMap[placementKey] = 0;
				}
				bottomAdjust = placementMap[placementKey];
				placementMap[placementKey] += clientHeight;

				if (yPositioner == "value" && (y || y === 0)) {
					bottom =
						Math.round(
							height - stx.pixelFromPrice(y, panel, yAxis) - clientHeight / 2
						) + "px";
				} else if (
					(yPositioner == "below_candle" || yPositioner == "under_candle") &&
					quote
				) {
					// under_candle deprecated
					val = quote[plotField];
					if (showsHighs)
						val = stx.getBarBounds(quote)[yAxis.flipped ? "high" : "low"];
					bottom =
						Math.round(
							height -
								stx.pixelFromPrice(val, panel, yAxis) -
								clientHeight -
								bottomAdjust
						) + "px";
				} else if (yPositioner == "on_candle" && quote) {
					val = quote[plotField];
					if (showsHighs) val = (quote.Low + quote.High) / 2;
					bottom =
						Math.round(
							height -
								stx.pixelFromPrice(val, panel, yAxis) -
								clientHeight / 2 -
								bottomAdjust
						) + "px";
				} else if (yPositioner == "top") {
					bottom =
						Math.round(height - clientHeight - bottomAdjust - panel.top) + "px";
				} else if (yPositioner == "bottom") {
					bottom = Math.round(bottomAdjust) + "px";
				} else if (quote) {
					//above_candle
					val = quote[plotField];
					if (showsHighs)
						val = stx.getBarBounds(quote)[yAxis.flipped ? "low" : "high"];
					bottom =
						Math.round(
							height - stx.pixelFromPrice(val, panel, yAxis) + bottomAdjust
						) + "px";
				}
				if (node.style.bottom != bottom) node.style.bottom = bottom;
			}
			CIQ.Marker.positionContentVerticalAndHorizontal(node);
		}
	};

	/**
	 * Base class to create an empty marker node that can then be styled. Used by {@link CIQ.Marker.Simple} and {@link CIQ.Marker.Performance}.
	 *  It is strongly recommended that you extend this class if you're building your own marker class.
	 * See {@tutorial Markers} tutorials for additional implementation instructions.
	 * @name CIQ.Marker.NodeCreator
	 * @constructor
	 */
	CIQ.Marker.NodeCreator = function () {};

	CIQ.Marker.NodeCreator.toNode = function () {
		return this.node;
	};

	/**
	 * Creates simple HTML nodes that can be used with a {@link CIQ.Marker}
	 *
	 * See {@tutorial Markers} tutorials for additional implementation instructions.
	 * @name CIQ.Marker.Simple
	 * @constructor
	 * @param {Object} params Parameters to describe the marker
	 * @param {string} params.type The marker type to be drawn.
	 * <br>Available options are:
	 * - "circle"
	 * - "square"
	 * - "callout"
	 * @param {string} params.headline The headline text to pop-up when clicked.
	 * @param {string} [params.category] The category class to add to your marker.
	 * <br>Available options are:
	 * - "news"
	 * - "earningsUp"
	 * - "earningsDown"
	 * - "dividend"
	 * - "filing"
	 * - "split"
	 * @param {string} [params.story] The story to pop-up when clicked.
	 * @example
	 * 	var datum = {
	 *		type: "circle",
	 *		headline: "This is a Marker for a Split",
	 *		category: "split",
	 *		story: "This is the story of a split"
	 * };
	 *
	 * 	var mparams = {
	 * 		stx: stxx,
	 * 		label: "Sample Events",
	 * 		xPositioner: "date",
	 * 		x: aDate,
	 * 		node: new CIQ.Marker.Simple(datum)
	 * 	};
	 *
	 * 	var marker = new CIQ.Marker(mparams);
	 */
	CIQ.Marker.Simple = function (params) {

		var node = (this.node = document.createElement("div"));
		node.className = "stx-marker";
		node.classList.add(params.type);
		if (params.category) node.classList.add(params.category);
		var visual = CIQ.newChild(node, "div", "stx-visual");
		CIQ.newChild(node, "div", "stx-stem");

		var expand;
		if (params.type == "callout") {
			var content = CIQ.newChild(visual, "div", "stx-marker-content");
			CIQ.newChild(content, "h4", null, params.headline);
			expand = CIQ.newChild(content, "div", "stx-marker-expand");
			CIQ.newChild(expand, "p", null, params.story);
		} else {
			expand = CIQ.newChild(node, "div", "stx-marker-expand");
			CIQ.newChild(expand, "h4", null, params.headline);
			CIQ.newChild(expand, "p", null, params.story);
			CIQ.safeClickTouch(expand, function (e) {
				node.classList.toggle("highlight");
			});
		}

		function cb() {
			CIQ.Marker.positionContentVerticalAndHorizontal(node);
		}
		CIQ.safeClickTouch(visual, function (e) {
			node.classList.toggle("highlight");
			setTimeout(cb, 10);
		});
		this.nodeType = "Simple";
		this.expand = expand;
	};

	CIQ.inheritsFrom(CIQ.Marker.Simple, CIQ.Marker.NodeCreator, false);
}

};
__js_standard_markers_(typeof window !== "undefined" ? window : global);
