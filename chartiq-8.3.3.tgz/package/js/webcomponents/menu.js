/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Menu web component `<cq-menu>`.
 *
 * Add attribute `cq-focus` to provide a query selector path to the element to focus when the
 * menu is opened.
 *
 * The node is contextually aware of its surroundings. Handles opening and closing
 * {@link WebComponents.cq-menu-dropdown}.
 *
 * @namespace WebComponents.cq-menu
 *
 * @example
 * <cq-menu class="ciq-menu stx-markers collapse">
 * 	   <span>Events</span>
 * 	   <cq-menu-dropdown>
 * 		   <cq-item class="square">Simple Square <span class="ciq-radio"><span></span></span>
 * 		   </cq-item>
 * 		   <cq-item class="circle">Simple Circle <span class="ciq-radio"><span></span></span>
 * 		   </cq-item>
 * 		   <cq-item class="callouts">Callouts <span class="ciq-radio"><span></span></span>
 * 		   </cq-item>
 * 		   <cq-item class="abstract">Abstract <span class="ciq-radio"><span></span></span>
 * 		   </cq-item>
 * 		   <cq-item class="none">None <span class="ciq-radio ciq-active"><span></span></span>
 * 		   </cq-item>
 * 	   </cq-menu-dropdown>
 * </cq-menu>
 */
class Menu extends HTMLElement {
	constructor() {
		super();
		this.activeClassName = "stxMenuActive";
		this.active = false;
	}

	/**
	 * READ ONLY. The value of the `cq-focus` attribute.
	 *
	 * @alias focusElement
	 * @memberof WebComponents.cq-menu
	 * @type String
	 * @since 7.5.0
	 */
	get focusElement() {
		return this.getAttribute("cq-focus");
	}

	connectedCallback() {
		if (this.attached) return;
		this.uiManager = CIQ.UI.getUIManager();

		this.attached = true;

		if (this.hasAttribute("readonly")) return;
		var self = this;
		function handleTap(e) {
			self.tap(e);
		}
		function handleCaptureTap(e) {
			self.captureTap(e);
		}
		this.addEventListener("stxtap", handleCaptureTap, true);
		CIQ.UI.stxtap(this, handleTap);
	}

	/**
	 * Captures a tap event *before* it descends down to what it is clicked on. The key thing this does is determine
	 * whether the thing clicked on was inside of a "cq-no-close" section. We do this on the way down, because the act
	 * of clicking on something may release it from the dom, making it impossible to figure out on propagation.
	 * @param {object} e Element
	 * @private
	 */
	captureTap(e) {
		var domChain = Array.from(CIQ.climbUpDomTree(e.target));
		// Determine if the tapped element, or any of its parents have a cq-no-close attribute
		this.noClose = domChain.filter(function (el) {
			var attr = el.getAttribute("cq-no-close");
			return attr !== null && attr !== false;
		}).length;

		// Determine if the tapped element was inside of something untappable, like a cq-heading or cq-separator
		if (!this.noClose) {
			this.noClose = domChain.filter(function (el) {
				return el.matches("cq-separator,cq-heading");
			}).length;
		}
	}

	close() {
		this.uiManager.closeMenu(this);
	}

	hide() {
		if (!this.active) return;
		this.unlift();
		this.classList.remove(this.activeClassName);
		this.active = false;
		// blur any input boxes that are inside the menu we're closing, to get rid of soft keyboard
		this.querySelectorAll("input").forEach(function (i) {
			if (i == document.activeElement) i.blur();
		});
		// Disable keyboardNavigation controls in the dropdown
		const dropdown = this.querySelector("cq-menu-dropdown");
		if (dropdown) {
			dropdown.disablekeyboardNavigation();
			// Remove focus from any selected menu item
			CIQ.UI.BaseComponent.prototype.removeFocused(
				dropdown.querySelectorAll("[cq-focused]")
			);
		}
		// Close the lookup component
		const lookup = this.querySelector("cq-lookup");
		if (lookup) lookup.close();
	}

	lift() {
		const context = CIQ.UI.getMyContext(this);
		const lifts = (this.lifts = this.uiManager.findLifts(this));
		for (let i = 0; i < lifts.length; i++) {
			// The lifted menu will no longer inherit the active theme class. Attach it directly to the element.
			if (context && context.config && context.config.themes) {
				let themes = Object.keys(context.config.themes.builtInThemes);
				// First remove any existing theme classes on the dialog
				lifts[i].classList.remove(...themes);
				let activeTheme = themes.find(
					(r) => context.topNode.classList.contains(r) === true
				);
				// Add the active theme class to the dialog
				if (activeTheme) lifts[i].classList.add(activeTheme);
			}
			this.uiManager.lift(lifts[i]);
		}
	}

	onKeyboardDeselection() {
		this.close();
	}

	open(params) {
		var stack = this.uiManager.activeMenuStack;
		for (var i = 0; i < stack.length; i++) {
			if (stack[i] === this) return;
		}
		this.uiManager.openMenu(this, params);
	}

	show(params) {
		if (this.active) return;
		this.active = true;
		this.classList.add(this.activeClassName);
		this.lift();
		// For good measure, call resize on any nested scrollables to give them
		// a chance to change their height and scrollbars
		this.querySelectorAll("cq-scroll, cq-menu-dropdown").forEach(function (s) {
			if (s.resize) s.resize();
		});
		// Pass keyboard navigation over to the dropdown if it exists
		if (this.keyboardNavigation) {
			const dropdown = this.querySelector("cq-menu-dropdown");
			if (dropdown)
				this.keyboardNavigation.setKeyControlElement(dropdown, true);
		}
	}

	tap(e) {
		e.stopPropagation();
		var uiManager = this.uiManager;
		if (this.active) {
			// tapping on the menu if it is open will close it
			if (!this.noClose) uiManager.closeMenu(this);
		} else {
			// if we've clicked on the label for the menu, then open the menu

			// If the tap came from within this menu's cq-menu-dropdown then this is probably an accidental
			// "re-open", which occurs when a click on a menu item causes an action that closes the menu, tricking
			// it into thinking it should re-open
			var insideDropdown = e.target.closest("cq-menu-dropdown");
			if (insideDropdown) return;

			var child = false;
			var parents = CIQ.climbUpDomTree(this.parentElement, "cq-menu,cq-dialog");
			for (var i = 0; i < parents.length; i++) {
				if (parents[i].active) child = true;
			}
			if (!child) uiManager.closeMenu(); // close all menus unless we're the child of an active menu (cascading)

			this.open();

			if (this.focusElement && !CIQ.isMobile) {
				const el = this.querySelector(this.focusElement);
				if (el) el.focus();
			}
		}
	}

	unlift() {
		var lifts = this.lifts;
		if (!lifts) return;
		for (var i = 0; i < lifts.length; i++) {
			this.uiManager.restoreLift(lifts[i]);
		}
		this.lifts = null;
	}
}

CIQ.UI.addComponentDefinition("cq-menu", Menu);
