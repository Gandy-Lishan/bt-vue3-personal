/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * The menu container web component `<cq-menu-container>`.
 *
 * Generates a menu based on the value of the `cq-name` attribute.
 *
 * @namespace WebComponents.cq-menu-container
 * @since 7.5.0
 *
 * @example
 * <cq-menu class="ciq-menu ciq-period">
 *     <span><cq-clickable stxbind="Layout.periodicity">1D</cq-clickable></span>
 *     <cq-menu-dropdown>
 *         <cq-menu-container cq-name="menuPeriodicity"></cq-menu-container>
 *     </cq-menu-dropdown>
 * </cq-menu>
 */
class MenuContainer extends CIQ.UI.ContextTag {
	/**
	 * Obtains the name of the menu and the items contained in the menu. Adds the default
	 * markup.
	 *
	 * @param {CIQ.UI.Context} context The chart user interface context.
	 *
	 * @alias setContext
	 * @memberof WebComponents.cq-menu-container
	 * @since 7.5.0
	 */
	setContext(context) {
		const setName = this.getAttribute("cq-name");
		if (setName && context.config) {
			// get menu items as array
			const menuItems = context.config.getMenu(setName);
			this.addDefaultMarkup(this, menuItems && menuItems.join(""));
			if (!this.innerHTML) {
				// hide container and heading if there is no content
				const container = CIQ.UI.BaseComponent.selfOrParentElement(
					this,
					"cq-menu-dropdown-section"
				);
				if (container) container.style.display = "none";
			}
			return;
		}
	}
}

CIQ.UI.addComponentDefinition("cq-menu-container", MenuContainer);
