/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

class WaveParameters extends CIQ.UI.ContextTag {
	static get observedAttributes() {
		return ["corrective", "decoration", "impulse", "show-lines"];
	}

	get corrective() {
		return this.getAttribute("corrective");
	}

	set corrective(attribute) {
		if (attribute) this.setAttribute("corrective", attribute.join(" "));
		else this.removeAttribute("corrective");
	}

	get decoration() {
		return this.getAttribute("decoration");
	}

	set decoration(attribute) {
		if (attribute) this.setAttribute("decoration", attribute);
		else this.removeAttribute("decoration");
	}

	get impulse() {
		return this.getAttribute("impulse");
	}

	set impulse(attribute) {
		if (attribute) this.setAttribute("impulse", attribute.join(" "));
		else this.removeAttribute("impulse");
	}

	get showLines() {
		return this.hasAttribute("show-lines");
	}

	set showLines(value) {
		if (value) {
			this.setAttribute("show-lines", "");
			this.lineToggleCheckbox.classList.add("ciq-active");
		} else this.removeAttribute("show-lines");
	}

	get template() {
		return this.getAttribute("template");
	}

	set template(attribute) {
		return this.setAttribute("template", attribute);
	}

	static templates() {
		return {
			"Grand Supercycle": {
				impulse: ["I", "II", "III", "IV", "V"],
				corrective: ["a", "b", "c"],
				decoration: "enclosed"
			},
			Supercycle: {
				impulse: ["I", "II", "III", "IV", "V"],
				corrective: ["a", "b", "c"],
				decoration: "parentheses"
			},
			Cycle: {
				impulse: ["I", "II", "III", "IV", "V"],
				corrective: ["a", "b", "c"],
				decoration: null
			},
			Primary: {
				impulse: ["1", "2", "3", "4", "5"],
				corrective: ["A", "B", "C"],
				decoration: "enclosed"
			},
			Intermediate: {
				impulse: ["1", "2", "3", "4", "5"],
				corrective: ["A", "B", "C"],
				decoration: "parentheses"
			},
			Minor: {
				impulse: ["1", "2", "3", "4", "5"],
				corrective: ["A", "B", "C"],
				decoration: null
			},
			Minute: {
				impulse: ["i", "ii", "iii", "iv", "v"],
				corrective: ["a", "b", "c"],
				decoration: "enclosed"
			},
			Minuette: {
				impulse: ["i", "ii", "iii", "iv", "v"],
				corrective: ["a", "b", "c"],
				decoration: "parentheses"
			},
			"Sub-Minuette": {
				impulse: ["i", "ii", "iii", "iv", "v"],
				corrective: ["a", "b", "c"],
				decoration: null
			}
		};
	}

	attributeChangedCallback(name, oldAttr, newAttr) {
		if (!this.stx) return;
		let vector = this.stx.currentVectorParameters;
		let waveParameters = vector.waveParameters || {};
		let parameters;
		switch (name) {
			case "template":
				let newTemplate = this.templates[newAttr];
				if (newTemplate) {
					parameters = {
						decoration: newTemplate.decoration
					};
				}
				break;
			case "impulse":
				let impulse = newAttr ? newAttr.split(" ") : newAttr;
				parameters = { impulse: impulse };
				break;
			case "corrective":
				let corrective = newAttr ? newAttr.split(" ") : newAttr;
				parameters = { corrective: corrective };
				break;
			case "decoration":
				parameters = { decoration: newAttr };
				break;
			case "show-lines":
				parameters = { showLines: this.showLines };
				break;
			default:
				break;
		}
		vector.waveParameters = Object.assign(waveParameters, parameters);
	}

	constructor() {
		super();
		this.templates = WaveParameters.templates();
	}

	connectedCallback() {
		if (this.attached) return;
		this.template = "Grand Supercycle";
		var tmpl = document.querySelector(
			'template[cq-wave-parameters], template[cq-wave-parameters="true"]'
		);
		CIQ.UI.makeFromTemplate(tmpl, this);
		this.templateHeader = this.querySelector(".ciq-active-template");
		this.impulseHeader = this.querySelector(".ciq-active-impulse");
		this.correctiveHeader = this.querySelector(".ciq-active-corrective");
		this.decorators = {
			blank: this.querySelector(".ciq-btn:nth-of-type(1n)"),
			parentheses: this.querySelector(".ciq-btn:nth-of-type(2n)"),
			enclosed: this.querySelector(".ciq-btn:nth-of-type(3n)")
		};
		this.lineToggleCheckbox = this.querySelector("span.ciq-checkbox");
		super.connectedCallback();
	}

	disconnectedCallback() {
		super.disconnectedCallback();
	}

	activate() {
		if (!this.stx) return;
		this.cvp = this.stx.currentVectorParameters;
		this.update(null, "template", this.template);
		this.showLines = true;
	}

	setContext() {
		this.stx = this.context.stx;
	}

	toggleLines() {
		let checkbox = this.lineToggleCheckbox;
		let active = checkbox.classList.contains("ciq-active");
		this.showLines = !active;
		if (active) checkbox.classList.remove("ciq-active");
		else checkbox.classList.add("ciq-active");
	}

	update(node, field, update) {
		let isTemplate = field === "template";

		if (!isTemplate) {
			if (field === "decoration") {
				for (let d in this.decorators) {
					this.decorators[d].classList.remove("ciq-active");
				}
				node.node.classList.add("ciq-active");
				this.decoration = node.node.getAttribute("decoration");
			} else if (field === "showLines") {
			} else {
				let u = update ? update.split(",") : update;
				this[field] = u;
				this[field + "Header"].innerHTML = u ? u.join(" ") : "- - -";
			}
			this.templateHeader.innerHTML = this.template = "Custom";
		} else {
			this.template = update;
			this.templateHeader.innerHTML = update;
			let newTemplate = this.templates[this.template];
			if (newTemplate) {
				this.impulse = newTemplate.impulse;
				this.impulseHeader.innerHTML = newTemplate.impulse.join(" ");

				this.corrective = newTemplate.corrective;
				this.correctiveHeader.innerHTML = newTemplate.corrective.join(" ");

				for (let d in this.decorators) {
					this.decorators[d].classList.remove("ciq-active");
				}
				let decorator = newTemplate.decoration || "blank";
				this.decorators[decorator].classList.add("ciq-active");
				this.decoration = decorator;
			} else
				this.cvp.waveParameters = {
					corrective: this.corrective.split(" "),
					impulse: this.impulse.split(" "),
					decoration: this.decoration
				};
		}
	}
}
CIQ.UI.addComponentDefinition("cq-wave-parameters", WaveParameters);
