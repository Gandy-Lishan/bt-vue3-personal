/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Undo web component `<cq-undo>`.
 *
 * @namespace WebComponents.cq-undo
 *
 * @example
 * <cq-undo-section>
 *     <cq-undo class="ciq-btn">Undo</cq-undo>
 *     <cq-redo class="ciq-btn">Redo</cq-redo>
 * </cq-undo-section>
 */
class Undo extends CIQ.UI.ContextTag {
	constructor() {
		super();
		this.redoButton = null;
		this.undostack = [];
		this.redostack = [];
		this.contexts = [];
	}

	connectedCallback() {
		if (this.attached) return;
		super.connectedCallback();
		var self = this;
		CIQ.UI.stxtap(this, function () {
			self.undo();
		});
	}

	/**
	 * Clears the stack of all redo or undo operations for the context
	 * @param  {CIQ.UI.Context} context The context to clear
	 * @alias clear
	 * @memberof WebComponents.cq-undo
	 */
	clear(context) {
		this.setButtonStyle();
	}

	handleEvent(context, type, data) {
		this.undostack.push({ context: context, drawings: data.before });
		this.redostack = [];
		this.setButtonStyle();
	}

	keyStroke(hub, key, e, keystroke) {
		if (key == "z" && (keystroke.ctrl || keystroke.cmd)) {
			// ctrl-z
			if (keystroke.shift) {
				this.redo();
			} else {
				this.undo();
			}
			return true;
		}
		if (key == "y" && (keystroke.ctrl || keystroke.cmd)) {
			// ctrl-y
			this.redo();
			return true;
		}
	}

	manageContext(context) {
		this.addClaim(this);
		var self = this;
		this.eventListeners.push(
			context.stx.addEventListener("undoStamp", function (data) {
				self.handleEvent(context, "undoStamp", data);
			})
		);
		this.contexts.push(context);
	}

	/**
	 * Reverts latest undone drawing.
	 * @alias redo
	 * @memberof WebComponents.cq-undo
	 */
	redo() {
		var state = this.redostack.pop();
		if (state) {
			var context = state.context;
			this.undostack.push({
				context: context,
				drawings: context.stx.exportDrawings()
			});
			var drawings = state.drawings;
			context.stx.abortDrawings(true);
			context.stx.importDrawings(drawings);
			context.stx.changeOccurred("vector");
			context.stx.draw();
		}
		this.setButtonStyle();
	}

	/**
	 * @private
	 */
	setButtonStyle() {
		if (this.undostack.length) {
			this.node.attr("cq-active", "true");
		} else {
			this.node.removeAttr("cq-active");
		}
		if (this.redoButton) {
			if (this.redostack.length) {
				this.redoButton.setAttribute("cq-active", "true");
			} else {
				this.redoButton.removeAttribute("cq-active");
			}
		}
	}

	setContext(context) {
		this.manageContext(this.context);

		var self = this;
		this.addInjection("append", "initializeChart", function () {
			self.undostack = [];
			self.redostack = [];
			self.clear();
		});
	}

	/**
	 * Reverts last drawing made.
	 * @alias undo
	 * @memberof WebComponents.cq-undo
	 */
	undo() {
		// If a drawing tool is in action, then pressing undo will kill the current tool
		var foundOne = false;
		for (var i = 0; i < this.contexts.length; i++) {
			if (this.contexts[i].stx.activeDrawing) {
				this.contexts[i].stx.undo();
				foundOne = true;
			}
		}
		if (foundOne) return;

		// otherwise proceed to popping off the stack
		var state = this.undostack.pop();
		if (state) {
			var context = state.context;
			this.redostack.push({
				context: context,
				drawings: context.stx.exportDrawings()
			});
			var drawings = state.drawings;
			context.stx.abortDrawings(true);
			context.stx.importDrawings(drawings);
			context.stx.changeOccurred("vector");
			context.stx.draw();
		}
		this.setButtonStyle();
	}
}

CIQ.UI.addComponentDefinition("cq-undo", Undo);
