/**
 *	8.3.0
 *	Generation date: 2021-11-02T13:40:51.589Z
 *	Client name: sundial capital research
 *	Package Type: Technical Analysis
 *	License type: annual
 *	Expiration date: "2022/10/01"
 *	Domain lock: ["127.0.0.1","localhost","sentimentrader.com","18.117.142.18","bt20.sentimentrader.com"]
 *	iFrame lock: true
 */

/***********************************************************
 * Copyright by ChartIQ, Inc.
 * Licensed under the ChartIQ, Inc. Developer License Agreement https://www.chartiq.com/developer-license-agreement
*************************************************************/
/*************************************** DO NOT MAKE CHANGES TO THIS LIBRARY FILE!! **************************************/
/* If you wish to overwrite default functionality, create a separate file with a copy of the methods you are overwriting */
/* and load that file right after the library has been loaded, but before the chart engine is instantiated.              */
/* Directly modifying library files will prevent upgrades and the ability for ChartIQ to support your solution.          */
/*************************************************************************************************************************/
/* eslint-disable no-extra-parens */


import { CIQ as _CIQ } from "../../js/componentUI.js";


/* global _CIQ, _timezoneJS, _SplinePlotter */

var CIQ = typeof _CIQ !== "undefined" ? _CIQ : _exports.CIQ;

/**
 * Chart Title web component `<cq-chart-title>`.
 *
 * Note, if the `cq-marker` is added to the element, and it is placed within the
 * chartArea, the element will sit above the chart bars.
 *
 * `<cq-symbol></cq-symbol>` will display `chart.symbol`.<br>
 * `<cq-symbol-description></cq-symbol-description>` will display the `chart.symbolDisplay`. See {@link CIQ.ChartEngine.Chart#symbolDisplay} for details on how to set this value.
 *
 * Set attribute `cq-browser-tab` to true in order to get the stock symbol and latest price to update in the browser tab.
 *
 * Set member `previousClose` to the prior day's closing price in order to calculate and display change.
 * If `previousClose` is not set, then `iqPrevClose` from the `dataSet` will be the default.<br>
 * Remember data is loaded asynchronously.
 * Be sure to reset this value once your initial data has been loaded by using the {@link CIQ.ChartEngine.loadChart} callback function.
 * ```
 * stx.loadChart(symbol, parameters, function(){
 *      document.querySelector("cq-chart-title").previousClose = yesterdays-closing-price;
 * }
 * ```
 *
 * The `cq-animate` attribute in the `cq-current-price` element can be used to change the price color to red or green based on the previous value.
 * Setting the attribute to "fade" will introduce a transition effect on the price which, while attractive, uses considerable CPU when there are rapid updates.
 * @namespace WebComponents.cq-chart-title
 * @example
 * <cq-chart-title>
 * 	<cq-symbol></cq-symbol>
 * 	<cq-chart-price>
 * 		<cq-current-price cq-animate></cq-current-price>
 * 		<cq-change>
 * 			<div class="ico"></div> <cq-todays-change></cq-todays-change> (<cq-todays-change-pct></cq-todays-change-pct>)
 * 		</cq-change>
 * 	</cq-chart-price>
 * </cq-chart-title>
 *
 * @example
 * //You can set a more descriptive name by using http://documentation.chartiq.com/CIQ.ChartEngine.Chart.html#symbolDisplay
 * // and then enabling that on the tile.
 *
 * //In your HTML file look for:
 * <cq-symbol></cq-symbol>
 * //and replace it with :
 * <cq-symbol-description></cq-symbol-description>
 *
 * //In your quote feed add the following line:
 * params.stx.chart.symbolDisplay=response.fullName;
 *
 * //Like so:
 * quotefeed.fetchInitialData=function (symbol, suggestedStartDate, suggestedEndDate, params, cb) {
 *  var queryUrl = this.url; // using filter:true for after hours
 *
 *  CIQ.postAjax(queryUrl, null, function(status, response){
 *   // process the HTTP response from the datafeed
 *   if(status==200){ // if successful response from datafeed
 *    params.stx.chart.symbolDisplay=response.fullName; // specify response name
 *    var newQuotes = quotefeed.formatChartData(response);
 *    cb({quotes:newQuotes, moreAvailable:true, attribution:{source:"simulator", exchange:"RANDOM"}}); // return the fetched data; init moreAvailable to enable pagination
 *   } else { // else error response from datafeed
 *    cb({error:(response?response:status)});	// specify error in callback
 *   }
 *  });
 * };
 *
 * @since
 * - 06-15-16
 * - 4.0.0 Browser tab now updates with stock symbol and latest price using `cq-browser-tab` attribute.
 * - 6.3.0 Negative close values are "N/A" change percentage.
 * - 6.3.0 Child tag `<cq-todays-change-pct>` is now optional.
 */

class ChartTitle extends CIQ.UI.ModalTag {
	constructor() {
		super();
		/**
		 * Keep this value up to date in order to calculate change from yesterday's close
		 * @type {Float}
		 * @alias previousClose
		 * @memberof WebComponents.cq-chart-title
		 */
		this.previousClose = null;
	}

	/**
	 * Begins the Title helper. This observes the chart and updates the title elements as necessary.
	 * @alias begin
	 * @memberof WebComponents.cq-chart-title
	 */
	begin() {
		var self = this;

		this.addDefaultMarkup();
		this.addInjection("append", "createDataSet", function () {
			self.update();
		});
		this.update();
	}

	disconnectedCallback() {
		if (this.context)
			CIQ.UI.unobserveProperty(
				"symbolObject",
				this.context.stx.chart,
				this.listener
			);
		super.disconnectedCallback();
	}

	initialize(params) {
		this.params = params ? params : {};
		if (typeof this.params.autoStart == "undefined")
			this.params.autoStart = true;
		this.marker = null;

		if (this.params.autoStart) this.begin();
	}

	setContext(context) {
		var self = this,
			stx = this.context.stx;
		this.listener = function (obj) {
			self.previousClose = stx.mostRecentClose("iqPrevClose");
		};
		CIQ.UI.observeProperty("symbolObject", stx.chart, this.listener);
		this.initialize();
	}

	/**
	 * Updates the values in the node
	 * @alias update
	 * @memberof WebComponents.cq-chart-title
	 */
	update() {
		var stx = this.context.stx;

		var node = this.node;
		var symbolDiv = node.find("cq-symbol");
		var symbolDescriptionDiv = node.find("cq-symbol-description");
		var currentPriceDiv = node.find("cq-current-price");
		var todaysChangeDiv = node.find("cq-todays-change");
		var todaysChangePctDiv = node.find("cq-todays-change-pct");
		var chartPriceDiv = node.find("cq-chart-price");
		var changeDiv = node.find("cq-change");
		var doUpdateBrowserTab =
			["false", "0", null].indexOf(this.getAttribute("cq-browser-tab")) == -1;
		var doUpdatePrice = chartPriceDiv.length;
		var symbol = stx.chart.symbol,
			symbolDisplay = stx.chart.symbolDisplay;
		var internationalizer = stx.internationalizer;
		var priceChanged = false;

		if (!symbol) node.removeClass("stx-show");
		else node.addClass("stx-show");

		var symbolChanged = symbolDiv.text() !== symbol && !!symbolDiv.text(symbol);

		if (stx.isHistoricalModeSet) {
			if (currentPriceDiv.text() !== "") currentPriceDiv.text("");
			changeDiv.css({ display: "none" });
			// only change the display so that you don't wreck the line spacing and parens
			return;
		}

		var todaysChange = "",
			todaysChangePct = 0,
			todaysChangeDisplay = "";
		var currentQuote = stx.getFirstLastDataRecord(
			stx.chart.dataSet,
			"Close",
			true
		);
		var currentPrice = "";
		var textPrice = "";
		if (currentQuote) currentPrice = currentQuote.Close;
		if (doUpdatePrice) {
			if (currentPrice !== "")
				textPrice = stx.formatYAxisPrice(
					currentPrice,
					stx.chart.panel,
					stx.chart.decimalPlaces
				);
			var oldPrice = parseFloat(currentPriceDiv.text());
			if (
				currentPriceDiv.text() !== textPrice &&
				!!currentPriceDiv.text(textPrice)
			) {
				priceChanged = true;
				var attr = currentPriceDiv.attr("cq-animate");
				if (typeof attr != "undefined") {
					CIQ.UI.animatePrice(
						currentPriceDiv,
						currentPrice,
						oldPrice,
						attr == "fade"
					);
				}
			}
		}

		if (symbolDescriptionDiv.text() !== (symbolDisplay || symbol))
			symbolDescriptionDiv.text(symbolDisplay || symbol);

		if (
			(doUpdatePrice || doUpdateBrowserTab) &&
			symbol &&
			(symbolChanged || priceChanged)
		) {
			// Default to iqPrevClose if the developer hasn't set this.previousClose
			var previousClose = currentQuote && currentQuote.iqPrevClose;
			if (!previousClose && previousClose !== 0)
				previousClose = this.previousClose;

			if (currentPrice || currentPrice === 0) {
				todaysChange = CIQ.fixPrice(currentPrice - previousClose);
				todaysChangePct = (todaysChange / previousClose) * 100;
				if (previousClose <= 0 || currentPrice < 0) {
					todaysChangeDisplay = "N/A";
				} else if (internationalizer) {
					todaysChangeDisplay = internationalizer.percent2.format(
						todaysChangePct / 100
					);
				} else {
					todaysChangeDisplay = todaysChangePct.toFixed(2) + "%";
				}
				changeDiv.css({ display: "block" });
			} else {
				changeDiv.css({ display: "none" });
			}
			var todaysChangeAbs = Math.abs(todaysChange);
			var txtChange = stx.formatYAxisPrice(
				todaysChangeAbs,
				stx.chart.panel,
				stx.chart.decimalPlaces
			);
			if (todaysChangeAbs) {
				if (todaysChangeDiv.text() !== txtChange)
					todaysChangeDiv.text(txtChange);
			}
			if (todaysChangePctDiv.length) {
				if (todaysChangePctDiv.text() !== todaysChangeDisplay)
					todaysChangePctDiv.text(todaysChangeDisplay);
			}
			if (todaysChangeDisplay !== "" && todaysChange > 0) {
				chartPriceDiv.removeClass("stx-down").addClass("stx-up");
			} else if (todaysChangeDisplay !== "" && todaysChange < 0) {
				chartPriceDiv.removeClass("stx-up").addClass("stx-down");
			} else {
				chartPriceDiv.removeClass("stx-down").removeClass("stx-up");
			}

			currentPrice = currentPrice !== undefined ? currentPrice : "";
			todaysChange = todaysChange !== undefined ? todaysChange : "";

			// These strange characters create some spacing so that the title appears
			// correctly in a browser tab
			this.title =
				symbol + " \u200b \u200b " + textPrice + " \u200b \u200b \u200b ";
			if (todaysChange > 0) {
				this.title += "\u25b2 " + txtChange;
			} else if (todaysChange < 0) {
				this.title += "\u25bc " + txtChange;
			}
			if (doUpdateBrowserTab) {
				document.title = this.title;
			}
		}
	}
}

ChartTitle.markup = `
		<cq-symbol></cq-symbol>
		<cq-chart-price>
			<cq-current-price cq-animate></cq-current-price>
			<cq-change>
				<div class="ico"></div>
				<cq-todays-change></cq-todays-change> (
				<cq-todays-change-pct></cq-todays-change-pct>)
			</cq-change>
		</cq-chart-price>
	`;
CIQ.UI.addComponentDefinition("cq-chart-title", ChartTitle);
